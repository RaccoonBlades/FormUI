<?php

namespace RacconAids;

use pocketmine\plugin\Pluginbase;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use jojoe77777\FormAPI

class main extends PluginBase implements listener{


  public function onEnable() {
      $this->getLogger()->Info();
      $this->getServer()->getPluginManager()->registerEvents($this, $this);
  }
  
  public function onDisable() {
      $this->getLogger()->info();
  }
  
  public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
      $player->$sender->getPlayer();
      switch($cmd->getName()) {
          case "cmc":
          $this->mainForm($player);
              break;
      }
      return true;
  }
  
  public function mainForm($player) {
      $formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
      $form = $formapi->createSimpleForm(function, (Player $event, array $data) {
          $result = $data[0];
          $player = $event->getPlayer();
          if($result == null) {
          }
          switch($result) {
              case 0:
              $this->maxForm($player);
              return;
              case 1;
              $this->exitForm($player);
              return;
       }
       }};
       $form->setTitle("Here Is HeadTitile");
       $form->setContent("Here Is SubTitle");
       $form->addButton("Here Is MaxForm Button");
       $form->addButton("this is exit");
       $form->sendToPlayer($player);
  }
  
  public function maxForm($player) {
      $formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
      $form = $formapi->createSimpleForm(function, (Player $event, array $data) {
          $result = $data[0];
          $player = $event->getPlayer();
          if($result == null) {
          }
          switch($result) {
              case 0:
              $this->mainForm($player);
              return;
      }
      }};
      $form->setTitle("MaxForm");
      $form->setContent("HI");
      $form->addButton("Back To Menu");
}